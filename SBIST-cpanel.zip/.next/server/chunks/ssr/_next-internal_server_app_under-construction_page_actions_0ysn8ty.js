module.exports=[21368,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_under-construction_page_actions_0ysn8ty.js.map