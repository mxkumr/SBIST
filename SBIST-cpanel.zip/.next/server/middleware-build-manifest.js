globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/_G66nI1NTB4nzO-18ezYJ/_buildManifest.js",
    "static/_G66nI1NTB4nzO-18ezYJ/_ssgManifest.js",
    "static/_G66nI1NTB4nzO-18ezYJ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0dhbjz-xsmu83.js",
    "static/chunks/15orcrkp-_9ct.js",
    "static/chunks/3peubv2924kx4.js",
    "static/chunks/07u_h6i539_wj.js",
    "static/chunks/turbopack-19b_bca3-52q-.js"
  ]
};
